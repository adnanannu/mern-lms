
import axios from 'axios';

const api = axios.create({
    baseURL: 'http://localhost:5000/api',
});

export const createClass = (teacherId, data) => api.post(`/zoom/teacher/${teacherId}/create`, data);
export const getTeacherClasses = (teacherId) => api.get(`/zoom/teacher/${teacherId}/classes`);
export const getStudentClasses = (studentId) => api.get(`/zoom/student/${studentId}/classes`);
                
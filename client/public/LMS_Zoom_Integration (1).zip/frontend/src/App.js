
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import TeacherDashboard from './components/TeacherDashboard';
import StudentDashboard from './components/StudentDashboard';

function App() {
    return (
        <Router>
            <Switch>
                <Route path="/teacher/:id" component={TeacherDashboard} />
                <Route path="/student/:id" component={StudentDashboard} />
            </Switch>
        </Router>
    );
}

export default App;
            
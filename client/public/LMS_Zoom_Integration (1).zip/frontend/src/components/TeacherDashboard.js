
import React, { useState, useEffect } from 'react';
import { createClass, getTeacherClasses } from '../services/api';

const TeacherDashboard = ({ match }) => {
    const teacherId = match.params.id;
    const [classes, setClasses] = useState([]);
    const [formData, setFormData] = useState({ subject: '', topic: '', startTime: '', duration: '' });

    useEffect(() => {
        const fetchClasses = async () => {
            const { data } = await getTeacherClasses(teacherId);
            setClasses(data);
        };
        fetchClasses();
    }, [teacherId]);

    const handleCreate = async (e) => {
        e.preventDefault();
        await createClass(teacherId, formData);
        setFormData({ subject: '', topic: '', startTime: '', duration: '' });
    };

    return (
        <div>
            <form onSubmit={handleCreate}>
                <input placeholder="Subject" value={formData.subject} onChange={(e) => setFormData({ ...formData, subject: e.target.value })} />
                <input placeholder="Topic" value={formData.topic} onChange={(e) => setFormData({ ...formData, topic: e.target.value })} />
                <input type="datetime-local" value={formData.startTime} onChange={(e) => setFormData({ ...formData, startTime: e.target.value })} />
                <input placeholder="Duration" value={formData.duration} onChange={(e) => setFormData({ ...formData, duration: e.target.value })} />
                <button type="submit">Create Class</button>
            </form>
            <ul>
                {classes.map((cls) => (
                    <li key={cls._id}>{cls.topic} - {cls.zoomLink}</li>
                ))}
            </ul>
        </div>
    );
};

export default TeacherDashboard;
                
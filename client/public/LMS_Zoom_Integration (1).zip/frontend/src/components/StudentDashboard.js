
import React, { useState, useEffect } from 'react';
import { getStudentClasses } from '../services/api';

const StudentDashboard = ({ match }) => {
    const studentId = match.params.id;
    const [classes, setClasses] = useState([]);

    useEffect(() => {
        const fetchClasses = async () => {
            const { data } = await getStudentClasses(studentId);
            setClasses(data);
        };
        fetchClasses();
    }, [studentId]);

    return (
        <div>
            <ul>
                {classes.map((cls) => (
                    <li key={cls._id}>
                        {cls.subject} - {cls.topic} - {cls.teacher.name}
                        <a href={cls.zoomLink} target="_blank" rel="noopener noreferrer">Join</a>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default StudentDashboard;
                
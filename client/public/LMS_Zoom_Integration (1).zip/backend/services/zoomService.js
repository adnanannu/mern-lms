
const axios = require('axios');
const jwt = require('jsonwebtoken');

const apiKey = process.env.ZOOM_API_KEY;
const apiSecret = process.env.ZOOM_API_SECRET;
const zoomBaseUrl = 'https://api.zoom.us/v2';

const generateZoomToken = () => {
    const payload = {
        iss: apiKey,
        exp: Math.floor(Date.now() / 1000) + 60 * 60,
    };
    return jwt.sign(payload, apiSecret);
};

exports.scheduleMeeting = async (topic, startTime, duration) => {
    const token = generateZoomToken();
    const config = {
        headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
        },
    };
    const body = {
        topic,
        type: 2,
        start_time: startTime,
        duration,
        timezone: 'UTC',
    };

    const response = await axios.post(`${zoomBaseUrl}/users/me/meetings`, body, config);
    return response.data.join_url;
};
            

const mongoose = require('mongoose');

const classSchema = new mongoose.Schema({
    subject: String,
    topic: String,
    teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    startTime: Date,
    duration: Number,
    zoomLink: String,
});

module.exports = mongoose.model('Class', classSchema);
            
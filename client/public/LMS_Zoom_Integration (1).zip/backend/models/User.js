
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    role: { type: String, enum: ['teacher', 'student'], required: true },
    subjects: [String],
});

module.exports = mongoose.model('User', userSchema);
            

const Class = require('../models/Class');
const User = require('../models/User');

exports.getStudentClasses = async (req, res) => {
    try {
        const student = await User.findById(req.params.studentId);
        const classes = await Class.find({ subject: { $in: student.subjects } }).populate('teacher', 'name');
        res.status(200).json(classes);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
            

const Class = require('../models/Class');
const { scheduleMeeting } = require('../services/zoomService');

exports.createClass = async (req, res) => {
    try {
        const { subject, topic, startTime, duration } = req.body;
        const zoomLink = await scheduleMeeting(topic, startTime, duration);
        const newClass = await Class.create({
            subject,
            topic,
            teacher: req.params.teacherId,
            startTime,
            duration,
            zoomLink,
        });
        res.status(201).json(newClass);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getClasses = async (req, res) => {
    try {
        const classes = await Class.find({ teacher: req.params.teacherId });
        res.status(200).json(classes);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
            
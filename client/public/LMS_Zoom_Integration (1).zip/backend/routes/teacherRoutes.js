
const express = require('express');
const { createClass, getClasses } = require('../controllers/teacherController');

const router = express.Router();

router.post('/:teacherId/create', createClass);
router.get('/:teacherId/classes', getClasses);

module.exports = router;
            
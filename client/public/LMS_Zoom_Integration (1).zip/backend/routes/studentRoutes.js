
const express = require('express');
const { getStudentClasses } = require('../controllers/studentController');

const router = express.Router();

router.get('/:studentId/classes', getStudentClasses);

module.exports = router;
            